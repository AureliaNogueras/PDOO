package modeloqytetet;

/**
 *
 * @author aurelia
 */
public enum MetodoSalirCarcel {
    TIRANDODADO, PAGANDOLIBERTAD
}
