package modeloqytetet;

/**
 *
 * @author aurelia
 */
public enum TipoCasilla {
    SALIDA, CALLE, SORPRESA, CARCEL, JUEZ, IMPUESTO, PARKING
}
