package modeloqytetet;

import java.util.ArrayList;

/**
 *
 * @author aurelia
 */
public class Jugador {
    private boolean encarcelado = false;
    private String nombre;
    private int saldo = 7500;
    private Sorpresa cartaLibertad; // Su tipo será SALIRCARCEL
    private Casilla casillaActual;
    private ArrayList<TituloPropiedad> propiedades;
    
    public Jugador(String nombre){
        this.nombre = nombre;
        encarcelado = false;
        saldo = 7500;
        cartaLibertad = null;
        casillaActual = null;
        propiedades = new ArrayList();
    }
    
    public Casilla getCasillaActual(){
        return casillaActual;
    }
    
    public boolean getEncarcelado(){
        return encarcelado;
    }
    
    //public boolean tengoPropiedades(){}
    
    //boolean actualizarPosicion(Casilla casilla){}
    
    //boolean comprarTitulo(){}
    
    //Sorpresa devolverCartaLibertad(){}
    
    void irACarcel(Casilla casilla){}
    
    void modificarSaldo(int cantidad){}
    
    //int obtenerCapital(){}
    
    //ArrayList<TituloPropiedad> obtenerPropiedadesHipotecadas(boolean hipotecada){}
    
    void pagarCobrarPorCasaYHotel(int cantidad){}
    
    //boolean pagarLibertad(int cantidad = PRECIO_LIBERTAD){}
    
    //boolean puedoEdificarCasa(Casilla casilla){}
    
    //boolean puedoEdificarHotel(Casilla casilla){}
    
    //boolean puedoHipotecar(Casilla casilla){}
    
    //boolean puedoPagarHipoteca(Casilla casilla){}
    
    //boolean puedoVenderPropiedad(Casilla casilla){}
    
    void setCartaLibertad(Sorpresa carta){
        cartaLibertad = carta;
    }
    
    void setCasillaActual(Casilla casilla){
        casillaActual = casilla;
    }
    
    void setEncarcelado(boolean encarcelado){
        this.encarcelado = encarcelado;
    }
    
    //boolean tengoCartaLibertad(){}
    
    void venderPropiedad(Casilla casilla){}
    
    //private int cuantasCasasHotelesTengo(){}
    
    private void eliminarDeMisPropiedades(Casilla casilla){}
    
    //private boolean esDeMiPropiedad(Casilla casilla){}
    
    //private boolean tengoSaldo(int cantidad){}
    
    @Override
    public String toString(){
        return "Jugador {" + "nombre =" + nombre + ", saldo =" + Integer.toString(saldo) + ", encarcelado =" +
                encarcelado + ", carta de libertad =" + cartaLibertad + ", casilla actual =" +
                casillaActual + ", propiedades =" + propiedades + "}\n";
    }
}
