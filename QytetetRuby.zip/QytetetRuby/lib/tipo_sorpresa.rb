#encoding: utf-8

module ModeloQytetet
  module TipoSorpresa
      IRACASILLA = :IrACasilla
      PAGARCOBRAR = :PagarCobrar
      SALIRCARCEL = :SalirCarcel
      PORJUGADOR = :PorJugador
      PORCASAHOTEL = :PorCasaHotel
  end
end
