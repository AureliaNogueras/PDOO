#encoding: utf-8

module ModeloQytetet
  module MetodoSalirCarcel
      TIRANDODADO = :TirandoDado
      PAGANDOLIBERTAD = :PagandoLibertad
  end
end
