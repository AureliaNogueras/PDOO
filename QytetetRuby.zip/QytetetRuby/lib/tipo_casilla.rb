#encoding: utf-8

module ModeloQytetet
  module TipoCasilla
      SALIDA = :Salida
      CALLE = :Calle 
      SORPRESA = :Sorpresa 
      CARCEL = :Carcel 
      JUEZ = :Juez 
      IMPUESTO = :Impuesto 
      PARKING = :Parking
  end
end
